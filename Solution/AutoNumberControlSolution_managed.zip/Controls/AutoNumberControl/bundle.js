var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./AutoNumberControl/index.ts");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./AutoNumberControl/index.ts":
/*!************************************!*\
  !*** ./AutoNumberControl/index.ts ***!
  \************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\n\nvar AutoNumberControl =\n/** @class */\nfunction () {\n  /**\r\n   * Empty constructor.\r\n   */\n  function AutoNumberControl() {}\n  /**\r\n   * Used to initialize the control instance. Controls can kick off remote server calls and other initialization actions here.\r\n   * Data-set values are not initialized here, use updateView.\r\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to property names defined in the manifest, as well as utility functions.\r\n   * @param notifyOutputChanged A callback method to alert the framework that the control has new outputs ready to be retrieved asynchronously.\r\n   * @param state A piece of data that persists in one session for a single user. Can be set at any point in a controls life cycle by calling 'setControlState' in the Mode interface.\r\n   * @param container If a control is marked control-type='starndard', it will receive an empty div element within which it can render its content.\r\n   */\n\n\n  AutoNumberControl.prototype.init = function (context, notifyOutputChanged, state, container) {\n    this._context = context;\n    this._container = container;\n    this._autoNumberDiv = document.createElement(\"div\");\n    this._refreshDiv = document.createElement(\"div\");\n    this._labelAutoNumber = document.createElement(\"label\");\n    this._imgRefresh = document.createElement(\"img\");\n\n    this._container.appendChild(this._autoNumberDiv);\n\n    this._container.appendChild(this._refreshDiv);\n\n    this._autoNumberDiv.appendChild(this._labelAutoNumber);\n\n    this._refreshDiv.appendChild(this._imgRefresh);\n\n    this._container.setAttribute(\"class\", \"container\");\n\n    this._autoNumberDiv.setAttribute(\"class\", \"autonumberdiv\");\n\n    this._refreshDiv.setAttribute(\"class\", \"refreshdiv\");\n\n    this._imgRefresh.setAttribute(\"class\", \"refreshimage\");\n\n    this._refreshAutoNumber = this.generateAutoNumber.bind(this, true, context);\n\n    this._imgRefresh.addEventListener(\"click\", this._refreshAutoNumber);\n  };\n  /**\r\n   * Called when any value in the property bag has changed. This includes field values, data-sets, global values such as container height and width, offline status, control metadata values such as label, visible, etc.\r\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to names defined in the manifest, as well as utility functions\r\n   */\n\n\n  AutoNumberControl.prototype.updateView = function (context) {\n    this._context = context;\n    this.generateAutoNumber(false, context);\n  };\n\n  AutoNumberControl.prototype.generateAutoNumber = function (isRefresh, context) {\n    // @ts-ignore\n    var formType = Xrm.Page.ui.getFormType(); // @ts-ignore\n\n    var crmAutoNumberFieldName = context.parameters.fieldNameProperty.attributes.LogicalName; // @ts-ignore\n\n    var entityName = Xrm.Page.data.entity.getEntityName(); // @ts-ignore\n\n    var recordId = Xrm.Page.data.entity.getId().replace(\"{\", \"\").replace(\"}\", \"\");\n    var pluralEntityName = this.getEntityPluralName(entityName);\n    var existingAutoNumber = this.getFieldValue(entityName, pluralEntityName, recordId, crmAutoNumberFieldName);\n\n    if (isRefresh || formType != \"1\" && existingAutoNumber == \"\") {\n      var autoNumber = this.processAutoNumber(entityName, pluralEntityName, recordId);\n\n      if (autoNumber != existingAutoNumber) {\n        this.saveRecord(pluralEntityName, recordId, crmAutoNumberFieldName, autoNumber);\n      }\n\n      this._labelAutoNumber.innerHTML = autoNumber;\n    } else {\n      this._labelAutoNumber.innerHTML = existingAutoNumber;\n    }\n  };\n\n  AutoNumberControl.prototype.processAutoNumber = function (entityName, pluralEntityName, recordId) {\n    var resultList = [];\n    var autoNumberFormat = this._context.parameters.formatProperty.raw;\n\n    for (var i = 0; i < autoNumberFormat.length; i++) {\n      var inputString = \"\";\n\n      if (autoNumberFormat.charAt(i) == '[') {\n        i++;\n\n        while (autoNumberFormat.charAt(i) != ']') {\n          inputString += autoNumberFormat.charAt(i);\n          i++;\n        }\n\n        if (inputString.indexOf('(') > 0) {\n          var fieldName = inputString.split('(')[0].toString();\n          var refFieldEntityNameAndId = this.getFieldEnityNameAndRecordId(entityName, pluralEntityName, recordId, fieldName);\n          var refEntityName = refFieldEntityNameAndId.split('@')[0];\n          var refRecordId = refFieldEntityNameAndId.split('@')[1];\n          var refEntityPluralName = this.getEntityPluralName(refEntityName);\n          var refEntityFieldName = inputString.split('(')[1].toString().slice(0, -1);\n          resultList.push(this.getFieldValue(refEntityName, refEntityPluralName, refRecordId, refEntityFieldName));\n        } else {\n          resultList.push(this.getFieldValue(entityName, pluralEntityName, recordId, inputString));\n        }\n      } else if (autoNumberFormat.charAt(i) == '{') {\n        i++;\n\n        while (autoNumberFormat.charAt(i) != '}') {\n          inputString += autoNumberFormat.charAt(i);\n          i++;\n        }\n\n        resultList.push(inputString);\n      } else {\n        while (autoNumberFormat.charAt(i) != '[' && autoNumberFormat.charAt(i) != '{') {\n          inputString += autoNumberFormat.charAt(i);\n          i++;\n        }\n\n        i--;\n        resultList.push(inputString);\n      }\n    }\n\n    return resultList.join('');\n  };\n  /**\r\n   * It is called by the framework prior to a control receiving new data.\r\n   * @returns an object based on nomenclature defined in manifest, expecting object[s] for property marked as “bound” or “output”\r\n   */\n\n\n  AutoNumberControl.prototype.getOutputs = function () {\n    return {};\n  };\n  /**\r\n   * Called when the control is to be removed from the DOM tree. Controls should use this call for cleanup.\r\n   * i.e. cancelling any pending remote calls, removing listeners, etc.\r\n   */\n\n\n  AutoNumberControl.prototype.destroy = function () {// Add code to cleanup control if necessary\n  };\n\n  AutoNumberControl.prototype.getFieldDataType = function (entityName, fieldName) {\n    var attributeType = \"\";\n    var req = new XMLHttpRequest(); // @ts-ignore\n\n    req.open(\"GET\", Xrm.Page.context.getClientUrl() + \"/api/data/v9.1/EntityDefinitions(LogicalName='\" + entityName + \"')/Attributes(LogicalName='\" + fieldName + \"')?$select=AttributeType\", false);\n    req.setRequestHeader(\"OData-MaxVersion\", \"4.0\");\n    req.setRequestHeader(\"OData-Version\", \"4.0\");\n    req.setRequestHeader(\"Accept\", \"application/json\");\n    req.setRequestHeader(\"Content-Type\", \"application/json; charset=utf-8\");\n    req.setRequestHeader(\"Prefer\", \"odata.include-annotations=\\\"*\\\"\");\n\n    req.onreadystatechange = function () {\n      if (this.readyState == 4) {\n        req.onreadystatechange = null;\n\n        if (this.status == 200) {\n          var result = JSON.parse(this.response);\n\n          if (result != undefined && result[\"AttributeType\"] != null) {\n            attributeType = result[\"AttributeType\"];\n          }\n        } else {//Xrm.Utility.alertDialog(this.statusText);\n        }\n      }\n    };\n\n    req.send();\n    return attributeType;\n  };\n\n  AutoNumberControl.prototype.getEntityPluralName = function (entityName) {\n    var entityPluralName = \"\";\n    var req = new XMLHttpRequest(); // @ts-ignore\n\n    req.open(\"GET\", Xrm.Page.context.getClientUrl() + \"/api/data/v9.1/EntityDefinitions(LogicalName='\" + entityName + \"')?$select=LogicalCollectionName\", false);\n    req.setRequestHeader(\"OData-MaxVersion\", \"4.0\");\n    req.setRequestHeader(\"OData-Version\", \"4.0\");\n    req.setRequestHeader(\"Accept\", \"application/json\");\n    req.setRequestHeader(\"Content-Type\", \"application/json; charset=utf-8\");\n    req.setRequestHeader(\"Prefer\", \"odata.include-annotations=\\\"*\\\"\");\n\n    req.onreadystatechange = function () {\n      if (this.readyState == 4) {\n        req.onreadystatechange = null;\n\n        if (this.status == 200) {\n          var result = JSON.parse(this.response);\n\n          if (result != undefined && result[\"LogicalCollectionName\"] != null) {\n            entityPluralName = result[\"LogicalCollectionName\"];\n          }\n        } else {//Xrm.Utility.alertDialog(this.statusText);\n        }\n      }\n    };\n\n    req.send();\n    return entityPluralName;\n  };\n\n  AutoNumberControl.prototype.getFieldValue = function (entityName, entityPluralName, recordId, fieldName) {\n    var fieldDataType = this.getFieldDataType(entityName, fieldName);\n    var fieldValue = \"\";\n\n    if (fieldDataType != \"\") {\n      var requestFieldName_1 = fieldName;\n\n      if (fieldDataType == \"Lookup\") {\n        requestFieldName_1 = \"_\" + fieldName + \"_value\";\n      }\n\n      var req = new XMLHttpRequest(); // @ts-ignore\n\n      req.open(\"GET\", Xrm.Page.context.getClientUrl() + \"/api/data/v9.1/\" + entityPluralName + \"(\" + recordId + \")?$select=\" + requestFieldName_1, false);\n      req.setRequestHeader(\"OData-MaxVersion\", \"4.0\");\n      req.setRequestHeader(\"OData-Version\", \"4.0\");\n      req.setRequestHeader(\"Accept\", \"application/json\");\n      req.setRequestHeader(\"Content-Type\", \"application/json; charset=utf-8\");\n      req.setRequestHeader(\"Prefer\", \"odata.include-annotations=\\\"*\\\"\");\n\n      req.onreadystatechange = function () {\n        if (this.readyState == 4) {\n          req.onreadystatechange = null;\n\n          if (this.status == 200) {\n            var responseFieldName = requestFieldName_1;\n\n            if (fieldDataType == \"Lookup\" || fieldDataType == \"Picklist\" || fieldDataType == \"Boolean\" || fieldDataType == \"Customer\") {\n              responseFieldName += \"@OData.Community.Display.V1.FormattedValue\";\n            }\n\n            var result = JSON.parse(this.response);\n\n            if (result != undefined && result[responseFieldName] != null) {\n              fieldValue = result[responseFieldName];\n            }\n          } else {//Xrm.Utility.alertDialog(this.statusText);\n          }\n        }\n      };\n\n      req.send();\n    }\n\n    return fieldValue;\n  };\n\n  AutoNumberControl.prototype.getFieldEnityNameAndRecordId = function (entityName, entityPluralName, recordId, fieldName) {\n    var fieldDataType = this.getFieldDataType(entityName, fieldName);\n    var fieldEntityNameAndRecordId = \"\";\n\n    if (fieldDataType != \"\" && (fieldDataType == \"Lookup\" || fieldDataType == \"Customer\")) {\n      var requestFieldName_2 = \"_\" + fieldName + \"_value\";\n      var req = new XMLHttpRequest(); // @ts-ignore\n\n      req.open(\"GET\", Xrm.Page.context.getClientUrl() + \"/api/data/v9.1/\" + entityPluralName + \"(\" + recordId + \")?$select=\" + requestFieldName_2, false);\n      req.setRequestHeader(\"OData-MaxVersion\", \"4.0\");\n      req.setRequestHeader(\"OData-Version\", \"4.0\");\n      req.setRequestHeader(\"Accept\", \"application/json\");\n      req.setRequestHeader(\"Content-Type\", \"application/json; charset=utf-8\");\n      req.setRequestHeader(\"Prefer\", \"odata.include-annotations=\\\"*\\\"\");\n\n      req.onreadystatechange = function () {\n        if (this.readyState == 4) {\n          req.onreadystatechange = null;\n\n          if (this.status == 200) {\n            var responseFieldName = requestFieldName_2;\n            responseFieldName = requestFieldName_2 + \"@Microsoft.Dynamics.CRM.lookuplogicalname\";\n            var result = JSON.parse(this.response);\n\n            if (result != undefined && result[responseFieldName] != null) {\n              fieldEntityNameAndRecordId = result[responseFieldName] + \"@\" + result[requestFieldName_2];\n            }\n          } else {//Xrm.Utility.alertDialog(this.statusText);\n          }\n        }\n      };\n\n      req.send();\n    }\n\n    return fieldEntityNameAndRecordId;\n  };\n\n  AutoNumberControl.prototype.saveRecord = function (entityName, recordId, fieldName, fieldValue) {\n    var entity = {}; // @ts-ignore\n\n    entity[fieldName] = fieldValue;\n    var req = new XMLHttpRequest(); // @ts-ignore\n\n    req.open(\"PATCH\", Xrm.Page.context.getClientUrl() + \"/api/data/v9.1/\" + entityName + \"(\" + recordId + \")\", true);\n    req.setRequestHeader(\"OData-MaxVersion\", \"4.0\");\n    req.setRequestHeader(\"OData-Version\", \"4.0\");\n    req.setRequestHeader(\"Accept\", \"application/json\");\n    req.setRequestHeader(\"Content-Type\", \"application/json; charset=utf-8\");\n\n    req.onreadystatechange = function () {\n      if (this.readyState === 4) {\n        req.onreadystatechange = null;\n\n        if (this.status === 204) {//Success - No Return Data - Do Something\n        } else {//Xrm.Utility.alertDialog(this.statusText);\n          }\n      }\n    };\n\n    req.send(JSON.stringify(entity));\n  };\n\n  return AutoNumberControl;\n}();\n\nexports.AutoNumberControl = AutoNumberControl;\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./AutoNumberControl/index.ts?");

/***/ })

/******/ });
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('APSPCFControls.AutoNumberControl', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.AutoNumberControl);
} else {
	var APSPCFControls = APSPCFControls || {};
	APSPCFControls.AutoNumberControl = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.AutoNumberControl;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}